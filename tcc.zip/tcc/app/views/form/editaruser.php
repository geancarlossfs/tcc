<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 07/05/18
 * Time: 13:39
 */
$codigo = $_GET['codigo'];
echo " esse é o id: $codigo\n";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Página Admin</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../node_modules/semantic-ui/dist/semantic.min.css">
    <script
        src="https://code.jquery.com/jquery-3.1.1.min.js"
        integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
        crossorigin="anonymous"></script>
    <script src="../../node_modules/semantic-ui/semantic.min.js"></script>
</head>
<body>
<form method="post" action="?action=editar&codigo=<?=$codigo; ?>">
        <legend>Editar Usuário</legend>

        <div>
        <label>Nome:</label>
        <input name="nome" type="text" value="<?=$usuario->getNome();?>">
        </div>

        <div>
        <label>Email:</label>
        <input name="email" type="email" value="<?=$usuario->getEmail();?>">
        </div>

        <div>
        <label>Senha:</label>
        <input name="senha" type="text" value="<?=$usuario->getSenha();?>">
        </div>

        <div>
        <label>Tipo:</label>
        <input name="tipo" type="text" value="<?=$usuario->getTipuser();?>">
        </div>

        <br>
        <div class="control-group">
            <div class="control">
                <input type="submit" name="gravar" id="singlebutton" class="btn btn-primary" value="Salvar">
            </div>
        </div>

</form>
</body>
</html>