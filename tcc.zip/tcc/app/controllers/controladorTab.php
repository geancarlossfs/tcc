<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 15/05/18
 * Time: 13:21
 */

require '../models/DBConexao.php';

$x = DBConexao::getConexao();

//POPULAR BANCO COM AS MARCAS

//$todasMarcas = file_get_contents("http://fipeapi.appspot.com/api/1/carros/marcas.json");
//$todasMarcas = json_decode($todasMarcas, true);
//
//
//foreach ($todasMarcas as $marca) {
// 	$idMarca = $marca['id'];
// 	$nome = $marca['fipe_name'];
//
//	$x->exec("INSERT INTO montadora (idmontadora, montadora) VALUES ($idMarca, '$nome')");
// }

//END


////POPULAR BANCO COM OS MODELOS
//
//$todosModelos = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculos/1.json");
//$todosModelos = json_decode($todosModelos, true);
//
//foreach ($todosModelos as $modelo) {
//    $idModelo = $modelo['id'];
//    $nome = $modelo['fipe_name'];
//    $x->exec("INSERT INTO modelo (nome_modelo, montadora_idmontadora) VALUES ('$nome', 1)");
//}

//END

//POPULAR COM AS EXPECIFICAÇÕES

//$preco = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/1/1/1991-1.json");
//$preco = json_decode($preco, true);
//
//$valor = $preco['preco'];
//
//$x->exec("INSERT INTO modelo_ano (ano,potencia,portas,preco,altura,comprimento,largura,cambio,velocidade,tanque_combustivel,tip_combustivel,porta_malas,tip_direcao,consumo_urb,consumo_rod,marcha,tip_tracao,porte,ocupantes,tip_freio,tip_veiculo,modelo_idmodelo)
//VALUES (1991, '?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?','?',1)");

//END

// $y = $_GET['marca'];
// // echo "SELECT * FROM montadora WHERE 'nome_montadora'=$y;";
// $dados = $x->query("SELECT * FROM montadora WHERE nome_montadora='$y'")->fetchAll(PDO::FETCH_ASSOC);

// print_r($dados);

// echo json_encode($dados);


////////////////////////////////COMEÇO CARRO 1////////////////////////////

$idMarca = $_POST['marca'];
$idModelo = $_POST['modelo'];
$idAno = $_POST['ano'];
echo $idAno;
//marca
$marcas = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculos/$idMarca.json");
$marcas = json_decode($marcas, true);


//Nome
$modelos = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca/$idModelo.json");
$modelos = json_decode($modelos, true);


//Ano
$anos = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca/$idModelo/$idAno.json");
$anos = json_decode($anos, true);


////////////////////////////COMEÇO CARRO 2/////////////////////////////////

$idMarca1 = $_POST['marca1'];
$idModelo1 = $_POST['modelo1'];
$idAno1 = $_POST['ano1'];

//marca
$marcas1 = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculos/$idMarca1.json");
$marcas1 = json_decode($marcas1, true);


//Nome
$modelos1 = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca1/$idModelo1.json");
$modelos1 = json_decode($modelos1, true);


//Ano
$anos1 = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca1/$idModelo1/$idAno1.json");
$anos1 = json_decode($anos1, true);


//////////////////////////////////////////COMEÇO CARRO 3/////////////////////////////////////////


$idMarca2 = $_POST['marca2'];
$idModelo2 = $_POST['modelo2'];
$idAno2 = $_POST['ano2'];

//marca
$marcas2 = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculos/$idMarca2.json");
$marcas2 = json_decode($marcas2, true);


//Nome
$modelos2 = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca2/$idModelo2.json");
$modelos2 = json_decode($modelos2, true);


//Ano
$anos2 = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca2/$idModelo2/$idAno2.json");
$anos2 = json_decode($anos2, true);

////////////////////////////////////////COMEÇO CARRO 4/////////////////////////////////////////////

$idMarca3 = $_POST['marca3'];
$idModelo3 = $_POST['modelo3'];
$idAno3 = $_POST['ano3'];

//marca
$marcas3 = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculos/$idMarca3.json");
$marcas3 = json_decode($marcas3, true);

//Nome
$modelos3 = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca3/$idModelo3.json");
$modelos3= json_decode($modelos3, true);

//Ano
$anos3 = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca3/$idModelo3/$idAno3.json");
$anos3 = json_decode($anos3, true);

?>
<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 19/03/18
 * Time: 16:00
 */
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Página Inicial</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../node_modules/semantic-ui/dist/semantic.min.css">
    <script
        src="https://code.jquery.com/jquery-3.1.1.min.js"
        integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
        crossorigin="anonymous"></script>
    <script src="../../node_modules/semantic-ui/semantic.min.js"></script>
    <style type="text/css">
        @media only screen and (max-width: 700px) {
            .ui.fixed.menu {
                display: none !important;
            }
        }
    </style>
</head>
<body>
<h1>Veiculo #1</h1>
    <form>
        <label>Marca</label>
        <input value="<?php print_r($marcas[0]['fipe_marca']); ?>">

        <label>Modelo</label>
        <input value="<?php print_r($modelos[0]['veiculo']); ?>">

        <label>Ano e Combustível</label>
        <input value="<?php print_r($anos['ano_modelo']); ?>">
        <input value="<?php print_r($anos['combustivel']); ?>">
    </form>


<h1>Veiculo #2</h1>
<form>
    <label>Marca</label>
    <input value="<?php print_r($marcas1[0]['fipe_marca']); ?>">

    <label>Modelo</label>
    <input value="<?php print_r($modelos1[0]['veiculo']); ?>">

    <label>Ano e Combustível</label>
    <input value="<?php print_r($anos1['ano_modelo']); ?>">
    <input value="<?php print_r($anos1['combustivel']); ?>">
</form>


<h1>Veiculo #3</h1>
<form>
    <label>Marca</label>
    <input value="<?php print_r($marcas2[0]['fipe_marca']); ?>">

    <label>Modelo</label>
    <input value="<?php print_r($modelos2[0]['veiculo']); ?>">

    <label>Ano e Combustível</label>
    <input value="<?php print_r($anos2['ano_modelo']); ?>">
    <input value="<?php print_r($anos2['combustivel']); ?>">
</form>


<h1>Veiculo #4</h1>
<form>
    <label>Marca</label>
    <input value="<?php print_r($marcas3[0]['fipe_marca']); ?>">

    <label>Modelo</label>
    <input value="<?php print_r($modelos3[0]['veiculo']); ?>">

    <label>Ano e Combustível</label>
    <input value="<?php print_r($anos3['ano_modelo']); ?>">
    <input value="<?php print_r($anos3['combustivel']); ?>">
</form>
</body>
</html>
