<?php
/**
 * Created by PhpStorm.
 * User: Gean Carlos
 * Date: 04/06/2018
 * Time: 16:06
 */

class Comentario
{
    

}