-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Tempo de geração: 24/05/2018 às 16:57
-- Versão do servidor: 5.7.21-0ubuntu0.16.04.1
-- Versão do PHP: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `mydb`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `modelo`
--

CREATE TABLE `modelo` (
  `idmodelo` int(11) NOT NULL,
  `nome_modelo` varchar(45) DEFAULT NULL,
  `montadora_idmontadora` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `modelo`
--

INSERT INTO `modelo` (`idmodelo`, `nome_modelo`, `montadora_idmontadora`) VALUES
(1, 'Integra GS 1.8', 1),
(2, 'Legend 3.2/3.5', 1),
(3, 'NSX 3.0', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `modelo_ano`
--

CREATE TABLE `modelo_ano` (
  `idveiculo` int(11) NOT NULL,
  `ano` varchar(45) DEFAULT NULL,
  `potencia` varchar(45) DEFAULT NULL,
  `portas` varchar(45) DEFAULT NULL,
  `preco` varchar(45) DEFAULT NULL,
  `altura` varchar(45) DEFAULT NULL,
  `comprimento` varchar(45) DEFAULT NULL,
  `largura` varchar(45) DEFAULT NULL,
  `cambio` varchar(45) DEFAULT NULL,
  `velocidade` varchar(45) DEFAULT NULL,
  `tanque_combustivel` varchar(45) DEFAULT NULL,
  `tip_combustivel` varchar(45) DEFAULT NULL,
  `porta_malas` varchar(45) DEFAULT NULL,
  `tip_direcao` varchar(45) DEFAULT NULL,
  `consumo_urb` varchar(45) DEFAULT NULL,
  `consumo_rod` varchar(45) DEFAULT NULL,
  `marcha` varchar(45) DEFAULT NULL,
  `tip_tracao` varchar(45) DEFAULT NULL,
  `porte` varchar(45) DEFAULT NULL,
  `ocupantes` varchar(45) DEFAULT NULL,
  `tip_freio` varchar(45) DEFAULT NULL,
  `tip_veiculo` varchar(45) DEFAULT NULL,
  `modelo_idmodelo` int(11) NOT NULL,
  `like` int(11) DEFAULT NULL,
  `dislike` int(11) DEFAULT NULL,
  `usuario_idusuario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `modelo_ano`
--

INSERT INTO `modelo_ano` (`idveiculo`, `ano`, `potencia`, `portas`, `preco`, `altura`, `comprimento`, `largura`, `cambio`, `velocidade`, `tanque_combustivel`, `tip_combustivel`, `porta_malas`, `tip_direcao`, `consumo_urb`, `consumo_rod`, `marcha`, `tip_tracao`, `porte`, `ocupantes`, `tip_freio`, `tip_veiculo`, `modelo_idmodelo`, `like`, `dislike`, `usuario_idusuario`) VALUES
(1, '1991', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `montadora`
--

CREATE TABLE `montadora` (
  `idmontadora` int(11) NOT NULL,
  `montadora` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `montadora`
--

INSERT INTO `montadora` (`idmontadora`, `montadora`) VALUES
(1, 'Acura'),
(2, 'Agrale'),
(3, 'Alfa Romeo'),
(4, 'AM Gen'),
(5, 'Asia Motors'),
(6, 'Audi'),
(7, 'BMW'),
(8, 'BRM'),
(10, 'Cadillac'),
(11, 'CBT Jipe'),
(12, 'Chrysler'),
(13, 'Citroën'),
(14, 'Cross Lander'),
(15, 'Daewoo'),
(16, 'Daihatsu'),
(17, 'Dodge'),
(18, 'Engesa'),
(19, 'Envemo'),
(20, 'Ferrari'),
(21, 'Fiat'),
(22, 'Ford'),
(23, 'GM - Chevrolet'),
(24, 'Gurgel'),
(25, 'Honda'),
(26, 'Hyundai'),
(27, 'Isuzu'),
(28, 'Jaguar'),
(29, 'Jeep'),
(30, 'JPX'),
(31, 'Kia Motors'),
(32, 'Lada'),
(33, 'Land Rover'),
(34, 'Lexus'),
(35, 'Lotus'),
(36, 'Maserati'),
(37, 'Matra'),
(38, 'Mazda'),
(39, 'Mercedes-Benz'),
(40, 'Mercury'),
(41, 'Mitsubishi'),
(42, 'Miura'),
(43, 'Nissan'),
(44, 'Peugeot'),
(45, 'Plymouth'),
(46, 'Pontiac'),
(47, 'Porsche'),
(48, 'Renault'),
(49, 'Rover'),
(50, 'Saab'),
(51, 'Saturn'),
(52, 'Seat'),
(54, 'Subaru'),
(55, 'Suzuki'),
(56, 'Toyota'),
(57, 'Troller'),
(58, 'Volvo'),
(59, 'VW - VolksWagen'),
(120, 'Walk'),
(123, 'Bugre'),
(125, 'SSANGYONG'),
(127, 'LOBINI'),
(136, 'CHANA'),
(140, 'Mahindra'),
(147, 'EFFA'),
(149, 'Fibravan'),
(152, 'HAFEI'),
(153, 'GREAT WALL'),
(154, 'JINBEI'),
(156, 'MINI'),
(157, 'smart'),
(161, 'CHERY'),
(163, 'Wake'),
(165, 'TAC'),
(167, 'MG'),
(168, 'LIFAN'),
(170, 'Fyber'),
(171, 'LAMBORGHINI'),
(177, 'JAC'),
(182, 'CHANGAN'),
(183, 'SHINERAY'),
(185, 'RAM'),
(186, 'RELY'),
(189, 'ASTON MARTIN'),
(190, 'FOTON'),
(195, 'Rolls-Royce'),
(199, 'GEELY'),
(207, 'Baby');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

CREATE TABLE `usuario` (
  `idusuario` int(11) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `senha` varchar(45) DEFAULT NULL,
  `tip_usuario` varchar(45) DEFAULT NULL,
  `nome` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario_has_modelo`
--

CREATE TABLE `usuario_has_modelo` (
  `usuario_idusuario` int(11) NOT NULL,
  `modelo_idmodelo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `modelo`
--
ALTER TABLE `modelo`
  ADD PRIMARY KEY (`idmodelo`),
  ADD KEY `fk_modelo_montadora1_idx` (`montadora_idmontadora`);

--
-- Índices de tabela `modelo_ano`
--
ALTER TABLE `modelo_ano`
  ADD PRIMARY KEY (`idveiculo`),
  ADD KEY `fk_veiculo_modelo1_idx` (`modelo_idmodelo`),
  ADD KEY `fk_veiculo_usuario1_idx` (`usuario_idusuario`);

--
-- Índices de tabela `montadora`
--
ALTER TABLE `montadora`
  ADD PRIMARY KEY (`idmontadora`);

--
-- Índices de tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`idusuario`);

--
-- Índices de tabela `usuario_has_modelo`
--
ALTER TABLE `usuario_has_modelo`
  ADD PRIMARY KEY (`usuario_idusuario`,`modelo_idmodelo`),
  ADD KEY `fk_usuario_has_modelo_modelo1_idx` (`modelo_idmodelo`),
  ADD KEY `fk_usuario_has_modelo_usuario1_idx` (`usuario_idusuario`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `modelo`
--
ALTER TABLE `modelo`
  MODIFY `idmodelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de tabela `modelo_ano`
--
ALTER TABLE `modelo_ano`
  MODIFY `idveiculo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `idusuario` int(11) NOT NULL AUTO_INCREMENT;
--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `modelo`
--
ALTER TABLE `modelo`
  ADD CONSTRAINT `fk_modelo_montadora1` FOREIGN KEY (`montadora_idmontadora`) REFERENCES `montadora` (`idmontadora`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para tabelas `modelo_ano`
--
ALTER TABLE `modelo_ano`
  ADD CONSTRAINT `fk_veiculo_modelo1` FOREIGN KEY (`modelo_idmodelo`) REFERENCES `modelo` (`idmodelo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_veiculo_usuario1` FOREIGN KEY (`usuario_idusuario`) REFERENCES `usuario` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para tabelas `usuario_has_modelo`
--
ALTER TABLE `usuario_has_modelo`
  ADD CONSTRAINT `fk_usuario_has_modelo_modelo1` FOREIGN KEY (`modelo_idmodelo`) REFERENCES `modelo` (`idmodelo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_usuario_has_modelo_usuario1` FOREIGN KEY (`usuario_idusuario`) REFERENCES `usuario` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
