
<br>
<br>

<link rel="stylesheet" type="text/css" href="../../../node_modules">

<div class="ui comments" align="right">
    <div class="comment">
        <a class="avatar">
            <img src="../../../assets/images/temer.jpg">
        </a>
        <div class="content">
            <a class="author"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></php></font></font></a>
            <div class="metadata">
                <div class="date"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1 dia atrás</font></font></div>
            </div>
            <div class="text">
                <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">As horas, os minutos e os segundos são lembretes visíveis de que seu esforço os colocou lá. </font></font></p>
                <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Preserve até a próxima corrida, quando o relógio permitir que você veja como os seus esforços são impermanentes.</font></font></p>
            </div>
            <div class="actions">
                <a class="reply"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Resposta</font></font></a>
            </div>
        </div>
    </div>
    <div class="comment">
        <a class="avatar">
            <img src="../../../assets/images/christian.jpg">
        </a>
        <div class="content">
            <a class="author"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Christian Rocha</font></font></a>
            <div class="metadata">
                <div class="date"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2 dias atrás</font></font></div>
            </div>
            <div class="text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                        Eu re-twittou isso.
                    </font></font></div>
            <div class="actions">
                <a class="reply"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Resposta</font></font></a>
            </div>
        </div>
    </div>
    <form class="ui reply form">
        <div class="field">
            <textarea></textarea>
        </div>
        <div class="ui primary submit labeled icon button">
            <i class="icon edit"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> Adicionar comentário
                </font></font></div>
    </form>
</div>