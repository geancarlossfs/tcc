<?php

if (isset($_GET['actioni'])){
    $action = $_GET['actioni'];
}else{
    $action = 'index';
}
switch ($action) {

    case 'comentar':

        $comentario = new Comentario($_POST['comentario_campo'], $_POST['id_user']);
        $crud = new CrudComentario();
        $crud->insertComentario($comentario);
        header('location: ../../controladorComentario.php?actioni=comentar');

        break;
}

