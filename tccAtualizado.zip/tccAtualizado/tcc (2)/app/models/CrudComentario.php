<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 19/06/18
 * Time: 08:29
 */

    require_once "DBConexao.php";

class CrudComentario
{
    private $conexao;

    public function __construct(){
        $this->conexao = DBConexao::getConexao();
    }

    public function getComentario($id){
        $sql = "SELECT * FROM comentario WHERE idcomentario=".$id;
        $result = $this->conexao->query($sql);
        $coment = $result->fetch(PDO::FETCH_ASSOC);
        $objcoment = new Comentario($coment['texto'], $coment['idusuario']);

        return $objcoment;
    }

    public function getComentarios(){
        $sql = "SELECT * FROM comentario";
        $result = $this->conexao->query($sql);
        $comentarios = $result->fetchAll(PDO::FETCH_ASSOC);
        foreach ($comentarios as $comentario){
            //$idcoment = $comentario['idcomentario'];
            $texto = $comentario['texto'];
            //$data = $comentario['data'];
            $iduser = $comentario['idusuario'];
            $obj = new Comentario($texto, $iduser);
            $listacomentarios[] = $obj;
        }
        return $listacomentarios;
    }

    public function getUsuarioComentario($cod_comentario){

        $sql = "SELECT nome FROM usuario, comentario where idusuario = idusuario and idcomentario = ".$cod_comentario;
        $resultado = $this->conexao->query($sql);

        $usu = $resultado->fetch(PDO::FETCH_ASSOC);
        return $usu;
    }



    public function updateComentario($comentario){
        $sql = "UPDATE comentario SET idcomentario='{$comentario->getIdcomentario()}', texto ='{$comentario->getTexto()}', data = '{$comentario->getData()}', idusuario ='{$comentario->getIdusuario()}'";
    try{
        $this->conexao->exec($sql);
    }catch (PDOException $e){
        return $e->getMessage();
    }

    }

    public function insertComentario(Comentario $comentario){
        $sql = "INSERT INTO comentario (texto, idusuario) VALUES ('{$comentario->getTexto()}','{$comentario->getIdusuario()}')";
        try{
            $this->conexao->exec($sql);
        }catch (PDOException $e){
            return $e->getMessage();
        }
    }

    public function deleteComentario(Comentario $id){
        $sql = "DELETE FROM comentario WHERE idcomentario=".$id;
        try{
            $this->conexao->exec($sql);
        }catch (PDOException $e){
            return $e->getMessage();
        }
    }

    public function verificaComentario(Comentario $comentario){
        if (strlen($comentario->getNome()) >=5 && strlen($comentario->getNome()) <= 50){
            if (strlen($comentario->setTexto()) >=1 && strlen($comentario->getTexto()) <=500){
                return $this->getComentario($comentario);
            }else{
                return false;
            }
        }else{
            return false;
        }
    }

}