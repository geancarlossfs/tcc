<?php
/**
 * Created by PhpStorm.
 * User: Gean Carlos
 * Date: 04/06/2018
 * Time: 16:06
 */

class Comentario
{
    public $idcomentario;
    public $texto;
    public $data = null;
    public $idusuario;

    public function __construct($texto, $idusuario, $data = null, $idcomentario = null)
    {
        $this->texto = $texto;
        $this->idusuario = $idusuario;
        $this->data = $data;
        $this->idcomentario = $idcomentario;

    }

    public function getIdcomentario()
    {
        return $this->idcomentario;
    }

    public function setIdcomentario($idcomentario)
    {
        $this->idcomentario = $idcomentario;
    }

    public function getTexto()
    {
        return $this->texto;
    }

    public function setTexto($texto)
    {
        $this->texto = $texto;
    }

    public function getData()
    {
        return $this->data;
    }

    public function setData($data)
    {
        $this->data = $data;
    }

    public function getIdusuario()
    {
        return $this->idusuario;
    }

    public function setIdusuario($idusuario)
    {
        $this->idusuario = $idusuario;
    }

}