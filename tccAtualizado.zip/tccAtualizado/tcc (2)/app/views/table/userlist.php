<!DOCTYPE html>
<html>
<head>
    <title>Página Admin</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../node_modules/semantic-ui/dist/semantic.min.css">
    <script
        src="https://code.jquery.com/jquery-3.1.1.min.js"
        integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
        crossorigin="anonymous"></script>
    <script src="../../node_modules/semantic-ui/dist/semantic.min.js"></script>
</head>
<body>
<br>
    <div class="ui attached stackable container top menu">
        <div class="item">
        <a href="?action=index"><button class="ui right labeled icon button">
                <i class="left arrow icon"></i>
                Voltar
            </button></a>
        </div>
    </div>
    <table class="ui celled padded table">
    <thead>
    <tr>
        <th>Id</th>
        <th>Nome</th>
        <th>Email</th>
        <th>Senha</th>
        <th>Tipo</th>
        <th>Ações</th>

    </tr>
    </thead>
    <tbody>
    <?php
        if($usuarios != null) {
            foreach ($usuarios as $usuario): ?>
                <tr>
                    <th scope="row"><?= $usuario->getId() ?></th>
                    <td><?= $usuario->getNome() ?></td>
                    <td><?= $usuario->getEmail() ?></td>
                    <td><?= $usuario->getSenha() ?></td>
                    <td><?= $usuario->getTipuser() ?></td>
                    <td><a href="controladorAcao.php?action=editar&codigo=<?= $usuario->getId(); ?>">Editar</a> | <a
                                href="controladorAcao.php?action=excluir&codigo=<?= $usuario->getId(); ?>">Excluir</a>
                    </td>
                </tr>
            <?php endforeach;
    }else{
            echo "<div class=\"ui middle aligned center aligned grid\">
        <div class=\"column\">
            <div class=\"content\">
                <h2 class='teal' \">Sem Usuários existentes</h2>
            </div>";
            $usuarios = new Usuario();
        }
    ?>
    </tbody>
</table>

<form class="ui large form" style="width: 400px; margin: 0 auto;" method="post" action="?action=adcadastrar">
    <div class="ui stacked segment">

        <!-- Text input-->
        <br>
        <label>Nome</label>
        <div class="ui left icon input">
            <i class="user icon"></i>
            <input maxlength="100" name="nome" type="text" placeholder="Digite o nome">
        </div>
        <br>
        <br>
        <!-- Email input-->
        <label>Email</label>
        <div class="ui left icon input">
            <i class="user icon"></i>
            <input maxlength="100" name="email" type="email" placeholder="Digite o Email">
        </div>
        <br>
        <br>
        <!-- Password input-->
        <label>Senha</label>
        <div class="ui left icon input">
            <i class="lock icon"></i>
            <input maxlength="100" name="senha" type="password" placeholder="Digite a senha">
        </div>
        <br>
        <br>
        <!-- Type input-->
        <label> Tipo</label>
        <div class="ui left icon input">
            <i class="chess pawn icon"></i>
            <input maxlength="100" name="tipo" type="text" placeholder="Digite o tipo">
        </div>
        <br>
        <br>
        <!-- Button -->
        <div class="field">
            <input class="ui fluid large teal button" type="submit" name="logar">
        </div>
    </div>
</form>
</body>
</html>