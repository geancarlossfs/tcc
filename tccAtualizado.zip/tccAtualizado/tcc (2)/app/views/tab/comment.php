 <div class="ui comments">

    <form method="post" class="ui form" action="../../controllers/controladorComentario.php?action=comentar">
        <input type="hidden" name="action" value="comentar">
        <div class="field">
            <textarea name="comentario_campo"></textarea>
        </div>
        <button type="submit" class="ui primary submit labeled icon button">
            <i class="icon edit" id="comentar"> </i>comentar</button>
    </form>


<?php

    $comentario = new CrudComentario();
    $comentarios = $comentario->getComentarios();

//    print_r($comentarios);
//    exit();

    foreach ($comentarios as $comentario): ?>

    <div class="comment ">
        <a class="avatar">
            <img src="https://png.icons8.com/color/1600/avatar.png">
        </a>
        <div class="content">
            <p> Fazer funçao que retorne o nome aqui</p>
            <a class="author"></a>
            <div class="metadata">
                <div class="date"></div>
            </div>
            <div class="text">
                <p><?= $comentario->getTexto()?></p>
            </div>
            <div class="actions">
                <a class="reply"></a>
            </div>
        </div>
    </div>

<!--    <form class="ui reply form">-->
<!--        <div class="field">-->
<!--            <textarea></textarea>-->
<!--        </div>-->
<!--        <div class="ui primary submit labeled icon button">-->
<!--            <i class="icon edit" id="comentar"> </i> responder-->
<!--        </div>-->
<!--    </form>-->

<?php endforeach; ?>

</div>