<?php

require_once '../models/CrudUsuario.php';
require_once '../models/Comentario.php';
require_once '../models/CrudComentario.php';

if (isset($_GET['action'])){
    $action = $_GET['action'];
}else{
    $action = 'index';
}
    switch ($action){

        case 'index':
            include_once "../views/index.php";
break;

        case 'cadastrar':
            $user = new Usuario($_POST['nome'], $_POST['email'], $_POST['senha'], 'comum');
            $usercrud = new CrudUsuario();
            $usercrud->insertUsuario($user);
            header('location: ../../index.php?action=login');
break;
        case 'listausuario' :
            $crud = new CrudUsuario();
            $usuarios = $crud->getUsuarios();
            include_once "../views/table/userlist.php";
break;

        case 'adcadastrar':
            $user = new Usuario($_POST['nome'], $_POST['email'], $_POST['senha'], $_POST['tipo']);
            $usercrud = new CrudUsuario();
            $usercrud->insertUsuario($user);
            header('location: ?action=listausuario');
break;

        case 'editar':
            $usercrud = new CrudUsuario();
            $codigo = $_GET['codigo'];

            if(!isset($_POST['gravar'])){//ainda nao preencheu o formulario
                $usuario = $usercrud->getUsuario($codigo);
                include_once "../views/form/editaruser.php";

            }else{
                $user = new Usuario( $_POST['nome'], $_POST['email'], $_POST['senha'], $_POST['tipo'], $codigo);
                $usercrud->updateUsuario($user);
                header('location: controladorAcao.php?action=listausuario');

            }

break;

        case 'excluir':
            $codigo = $_GET['codigo'];
            $usercrud = new CrudUsuario();
            $usercrud->excluirUsuario($codigo);
            header('location: controladorAcao.php?action=listausuario');
break;

        case 'login':

            if(isset($_POST['nome']) and isset($_POST['senha'])) {
            $user = new Usuario($_POST['nome'], '@gmail.com', $_POST['senha']);
            $usercrud = new CrudUsuario();
            if ($usercrud->loginUser($user) == 1){
                session_start();
                $_SESSION['logado'] = 'sim';
            switch ($usercrud->verificaTipo($user)) {
                case 'comum':
                    header('location: ?action=index');
                break;

                case 'admin':
                    $_SESSION['tipo'] = 'admin';
                    header('location: ?action=index');
                break;
            }
            } else {
                    header('location: ?actioni=login&erro=1');
            }
            }
break;

        case 'sair':
            session_start();
            session_destroy();
            header('location: ?action=index');
break;

}