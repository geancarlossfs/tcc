<?php

if (isset($_GET['action'])){
    $action = $_GET['action'];
}else{
    $action = 'index';
}
switch ($action) {

    case 'comentar':

        $comentario = new Comentario(null, $_POST['texto'], null, $_POST['idusuario']);
        $crud = new CrudComentario();
        $crud->insertComentario($comentario);
        header('location: ../../controladorComentario.php?actioni=comentar');

    break;

//    case 'inserir':
//
//        if (!isset($_POST['gravar'])) {
//            include('../view/template/cabecalho.php');
//            include('../view/categoria/inserir.php');
//            include('../view/template/rodape.php');
//        }else{
//            $cat = new Categoria(null, $_POST['nome'], $_POST['descricao']);
//            $crud = new CategoriaCrud();
//            $crud->insertCategoria($cat);
//            header('Location: categoria.php');
//        }
//        break;
}