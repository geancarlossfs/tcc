<?php
/**
 * Created by PhpStorm.
 * User: Gean Carlos
 * Date: 04/06/2018
 * Time: 16:06
 */

class Comentario
{
    private $idcomentario;
    private $texto;
    private $data;
    private $idusuario;

    public function __construct($idcomentario = null, $texto = null, $data = null, $idusuario = null){
    }

    public function getIdcomentario()
    {
        return $this->idcomentario;
    }

    public function setIdcomentario($idcomentario)
    {
        $this->idcomentario = $idcomentario;
    }

    public function getTexto()
    {
        return $this->texto;
    }

    public function setTexto($texto)
    {
        $this->texto = $texto;
    }

    public function getData()
    {
        return $this->data;
    }

    public function setData($data)
    {
        $this->data = $data;
    }

    public function getIdusuario()
    {
        return $this->idusuario;
    }

    public function setIdusuario($idusuario)
    {
        $this->idusuario = $idusuario;
    }

}