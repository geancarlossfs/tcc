<?php

require_once '../../models/CrudUsuario.php';

$crudComentario = new CrudComentario();
@$comentarios = $crudComentario->getComentarios();
foreach ($comentarios as $comentario):

?>
<div class="<?= $comentario->idusuario ?>" style="border-top: 2px solid #000; margin-bottom: 2%">
    <p style="float: left"><i class="fa fa-user-circle" aria-hidden="true"></i> <b><?php $iduser = $comentario->idusuario;

    $crud = new CrudUsuario();
    $usuario = $crud->getUsuario();
    $nome = $usuario->getNome();
    echo $nome; ?></b></p>

    <br>
    <p>
        <?= $comentario->texto ?>
        <a id="excluir" href="controlerComentario.php?acao=excluir&idcomentario=<?= $comentario->id_comentario;
        ?>&idusercomentario=<?= $comentario->id_usuario ?>&iduserlogado=<?= $_GET['iduser'] ?>&idlocal=<?= $_GET['idlocal'] ?>
        "class="fa fa-trash"></a>
    </p>
</div>
<?php
endforeach;

?>
}
        <?php
if (@$_GET['erro'] == 1){?>
    <div class="error-text" style="color: red">Só é possivel excluir seus prórios comentarios!</div>
<?php } ?>
<form method="post" action="controlerComentario.php?acao=cadastrar">
    <input type="text" name="texto" placeholder="Digite seu comentario">
    <input type="hidden" name="iduser" value="<?= $_SESSION['id']; ?>">
    <button type="submit" class="bnt btn-success">Comentar</button>
</form>

<!--<br>-->
<!--<br>-->
<!---->
<!--<link rel="stylesheet" type="text/css" href="../../../node_modules">-->
<!---->
<!--<div class="ui comments" align="right">-->
<!--    <div class="comment">-->
<!--        <a class="avatar">-->
<!--            <img src="../../../assets/images/temer.jpg">-->
<!--        </a>-->
<!--        <div class="content">-->
<!--            <a class="author"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></php></font></font></a>-->
<!--            <div class="metadata">-->
<!--                <div class="date"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1 dia atrás</font></font></div>-->
<!--            </div>-->
<!--            <div class="text">-->
<!--                <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">As horas, os minutos e os segundos são lembretes visíveis de que seu esforço os colocou lá. </font></font></p>-->
<!--                <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Preserve até a próxima corrida, quando o relógio permitir que você veja como os seus esforços são impermanentes.</font></font></p>-->
<!--            </div>-->
<!--            <div class="actions">-->
<!--                <a class="reply"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Resposta</font></font></a>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--    <div class="comment">-->
<!--        <a class="avatar">-->
<!--            <img src="../../../assets/images/christian.jpg">-->
<!--        </a>-->
<!--        <div class="content">-->
<!--            <a class="author"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Christian Rocha</font></font></a>-->
<!--            <div class="metadata">-->
<!--                <div class="date"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2 dias atrás</font></font></div>-->
<!--            </div>-->
<!--            <div class="text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-->
<!--                        Eu re-twittou isso.-->
<!--                    </font></font></div>-->
<!--            <div class="actions">-->
<!--                <a class="reply"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Resposta</font></font></a>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--    <form class="ui reply form">-->
<!--        <div class="field">-->
<!--            <textarea></textarea>-->
<!--        </div>-->
<!--        <div class="ui primary submit labeled icon button">-->
<!--            <i class="icon edit"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> Adicionar comentário-->
<!--                </font></font></div>-->
<!--    </form>-->
<!--</div>-->