<div class="ui inverted vertical attached bottom footer segment foot">
    <div class="ui center aligned container">
        <h3>Instituto Federal Catarinense</h3>
        <div class="ui horizontal inverted small divided link list">
            <a class="item" href="https://www.google.com.br/maps/place/Instituto+Federal+Catarinense+-+Campus+Araquari/@-26.394753,-48.7379352,15z/data=!4m5!3m4!1s0x0:0x34c75ce16022aa6a!8m2!3d-26.394753!4d-48.7379352">Site Map</a>
        </div>
    </div>
</div>
</body>
</html>