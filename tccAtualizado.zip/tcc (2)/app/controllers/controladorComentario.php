<?php

if (isset($_GET['action'])){
    $action = $_GET['action'];
}else{
    $action = 'index';
}
switch ($action) {

    case 'comentar':

        $comentario = new Comentario(null, $_POST['texto'], null, $_POST['idusuario']);
        $crud = new CrudComentario();
        $crud->insertComentario($comentario);
        header('location: ../../controladorComentario.php?actioni=comentar');

        break;

}

