-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Tempo de geração: 18/05/2018 às 17:14
-- Versão do servidor: 5.7.21-0ubuntu0.16.04.1
-- Versão do PHP: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `bd_auto1`
--

-- --------------------------------------------------------

--
-- Estrutura para table `ano`
--

CREATE TABLE `ano` (
  `id_ano` int(11) NOT NULL,
  `ano` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para table `ano`
--

INSERT INTO `ano` (`id_ano`, `ano`) VALUES
(1, '2017'),
(2, '2017'),
(3, '2016');

-- --------------------------------------------------------

--
-- Estrutura para table `comentario`
--

CREATE TABLE `comentario` (
  `idcomentario` int(11) NOT NULL,
  `data` date DEFAULT NULL,
  `texto` text,
  `idcarro` int(11) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para table `comparacao`
--

CREATE TABLE `comparacao` (
  `comparacao` int(11) NOT NULL,
  `idcomparacao` int(11) NOT NULL,
  `idcarro` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para table `favoritos`
--

CREATE TABLE `favoritos` (
  `idfavoritos` int(11) NOT NULL,
  `data` date DEFAULT NULL,
  `id_user` int(11) NOT NULL,
  `comparacao` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para table `modelo`
--

CREATE TABLE `modelo` (
  `idmodelo` int(11) NOT NULL,
  `nomemodelo` varchar(45) DEFAULT NULL,
  `idmontadora` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para table `montadora`
--

CREATE TABLE `montadora` (
  `idmontadora` int(11) NOT NULL,
  `nome_montadora` varchar(45) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Fazendo dump de dados para table `montadora`
--

INSERT INTO `montadora` (`idmontadora`, `nome_montadora`) VALUES
(1, 'Acura'),
(2, 'Agrale'),
(3, 'Alfa Romeo'),
(4, 'AM Gen'),
(5, 'Asia Motors'),
(189, 'ASTON MARTIN'),
(6, 'Audi'),
(207, 'Baby'),
(7, 'BMW'),
(8, 'BRM'),
(123, 'Bugre'),
(10, 'Cadillac'),
(11, 'CBT Jipe'),
(136, 'CHANA'),
(182, 'CHANGAN'),
(161, 'CHERY'),
(12, 'Chrysler'),
(13, 'Citroën'),
(14, 'Cross Lander'),
(15, 'Daewoo'),
(16, 'Daihatsu'),
(17, 'Dodge'),
(147, 'EFFA'),
(18, 'Engesa'),
(19, 'Envemo'),
(20, 'Ferrari'),
(21, 'Fiat'),
(149, 'Fibravan'),
(22, 'Ford'),
(190, 'FOTON'),
(170, 'Fyber'),
(199, 'GEELY'),
(23, 'GM - Chevrolet'),
(153, 'GREAT WALL'),
(24, 'Gurgel'),
(152, 'HAFEI'),
(25, 'Honda'),
(26, 'Hyundai'),
(27, 'Isuzu'),
(177, 'JAC'),
(28, 'Jaguar'),
(29, 'Jeep'),
(154, 'JINBEI'),
(30, 'JPX'),
(31, 'Kia Motors'),
(32, 'Lada'),
(171, 'LAMBORGHINI'),
(33, 'Land Rover'),
(34, 'Lexus'),
(168, 'LIFAN'),
(127, 'LOBINI'),
(35, 'Lotus'),
(140, 'Mahindra'),
(36, 'Maserati'),
(37, 'Matra'),
(38, 'Mazda'),
(39, 'Mercedes-Benz'),
(40, 'Mercury'),
(167, 'MG'),
(156, 'MINI'),
(41, 'Mitsubishi'),
(42, 'Miura'),
(43, 'Nissan'),
(44, 'Peugeot'),
(45, 'Plymouth'),
(46, 'Pontiac'),
(47, 'Porsche'),
(185, 'RAM'),
(186, 'RELY'),
(48, 'Renault'),
(195, 'Rolls-Royce'),
(49, 'Rover'),
(50, 'Saab'),
(51, 'Saturn'),
(52, 'Seat'),
(183, 'SHINERAY'),
(157, 'smart'),
(125, 'SSANGYONG'),
(54, 'Subaru'),
(55, 'Suzuki'),
(165, 'TAC'),
(56, 'Toyota'),
(57, 'Troller'),
(58, 'Volvo'),
(59, 'VW - VolksWagen'),
(163, 'Wake'),
(120, 'Walk');

-- --------------------------------------------------------

--
-- Estrutura para table `triade`
--

CREATE TABLE `triade` (
  `id_versao` int(11) NOT NULL,
  `id_ano` int(11) NOT NULL,
  `idmodelo` int(11) NOT NULL,
  `idcarro` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para table `usuario`
--

CREATE TABLE `usuario` (
  `id_user` int(11) NOT NULL,
  `senha` varchar(10) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `tip_user` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para table `veiculo`
--

CREATE TABLE `veiculo` (
  `idcarro` int(11) NOT NULL,
  `potencia` varchar(45) DEFAULT NULL,
  `portas` varchar(45) DEFAULT NULL,
  `preco` varchar(45) DEFAULT NULL,
  `altura` varchar(45) DEFAULT NULL,
  `comprimento` varchar(45) DEFAULT NULL,
  `largura` varchar(45) DEFAULT NULL,
  `cambio` varchar(45) DEFAULT NULL,
  `velocidade` varchar(45) DEFAULT NULL,
  `tanque_combustivel` varchar(45) DEFAULT NULL,
  `tip_combustivel` varchar(45) DEFAULT NULL,
  `porta_malas` varchar(45) DEFAULT NULL,
  `tip_direcao` varchar(45) DEFAULT NULL,
  `consumo_urb` varchar(45) DEFAULT NULL,
  `consumo_rod` varchar(45) DEFAULT NULL,
  `marcha` varchar(45) DEFAULT NULL,
  `tip_tracao` varchar(45) DEFAULT NULL,
  `porte` varchar(45) DEFAULT NULL,
  `ocupantes` varchar(45) DEFAULT NULL,
  `tip_freio` varchar(45) DEFAULT NULL,
  `tip_veiculo` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para table `versao`
--

CREATE TABLE `versao` (
  `id_versao` int(11) NOT NULL,
  `versao` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para table `versao`
--

INSERT INTO `versao` (`id_versao`, `versao`) VALUES
(1, 'Fifty 6.2 V8'),
(2, 'SS 6.2 V8'),
(3, 'SS 6.2 V8 Conversivel'),
(4, 'Sport 2.4'),
(5, 'Sport 2.4');

--
-- Índices de tabelas apagadas
--

--
-- Índices de table `ano`
--
ALTER TABLE `ano`
  ADD PRIMARY KEY (`id_ano`);

--
-- Índices de table `comentario`
--
ALTER TABLE `comentario`
  ADD PRIMARY KEY (`idcomentario`),
  ADD KEY `fk_comentario_carro1_idx` (`idcarro`),
  ADD KEY `fk_comentario_usuario1_idx` (`id_user`);

--
-- Índices de table `comparacao`
--
ALTER TABLE `comparacao`
  ADD PRIMARY KEY (`comparacao`),
  ADD KEY `fk_comparacao_veiculo1_idx` (`idcarro`);

--
-- Índices de table `favoritos`
--
ALTER TABLE `favoritos`
  ADD PRIMARY KEY (`idfavoritos`),
  ADD KEY `fk_favoritos_usuario1_idx` (`id_user`),
  ADD KEY `fk_favoritos_comparacao1_idx` (`comparacao`);

--
-- Índices de table `modelo`
--
ALTER TABLE `modelo`
  ADD PRIMARY KEY (`idmodelo`),
  ADD KEY `fk_modelo_montadora1_idx` (`idmontadora`);

--
-- Índices de table `montadora`
--
ALTER TABLE `montadora`
  ADD PRIMARY KEY (`idmontadora`),
  ADD UNIQUE KEY `nome_montadora` (`nome_montadora`);

--
-- Índices de table `triade`
--
ALTER TABLE `triade`
  ADD KEY `fk_versao_has_ano_ano1_idx` (`id_ano`),
  ADD KEY `fk_versao_has_ano_versao1_idx` (`id_versao`),
  ADD KEY `fk_versao_has_ano_modelo1_idx` (`idmodelo`),
  ADD KEY `fk_triade_veiculo1_idx` (`idcarro`);

--
-- Índices de table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_user`);

--
-- Índices de table `veiculo`
--
ALTER TABLE `veiculo`
  ADD PRIMARY KEY (`idcarro`);

--
-- Índices de table `versao`
--
ALTER TABLE `versao`
  ADD PRIMARY KEY (`id_versao`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de table `ano`
--
ALTER TABLE `ano`
  MODIFY `id_ano` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de table `comentario`
--
ALTER TABLE `comentario`
  MODIFY `idcomentario` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de table `comparacao`
--
ALTER TABLE `comparacao`
  MODIFY `comparacao` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de table `favoritos`
--
ALTER TABLE `favoritos`
  MODIFY `idfavoritos` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de table `modelo`
--
ALTER TABLE `modelo`
  MODIFY `idmodelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de table `versao`
--
ALTER TABLE `versao`
  MODIFY `id_versao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `comentario`
--
ALTER TABLE `comentario`
  ADD CONSTRAINT `fk_comentario_carro1` FOREIGN KEY (`idcarro`) REFERENCES `veiculo` (`idcarro`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_comentario_usuario1` FOREIGN KEY (`id_user`) REFERENCES `usuario` (`id_user`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para tabelas `comparacao`
--
ALTER TABLE `comparacao`
  ADD CONSTRAINT `fk_comparacao_veiculo1` FOREIGN KEY (`idcarro`) REFERENCES `veiculo` (`idcarro`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para tabelas `favoritos`
--
ALTER TABLE `favoritos`
  ADD CONSTRAINT `fk_favoritos_comparacao1` FOREIGN KEY (`comparacao`) REFERENCES `comparacao` (`comparacao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_favoritos_usuario1` FOREIGN KEY (`id_user`) REFERENCES `usuario` (`id_user`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para tabelas `modelo`
--
ALTER TABLE `modelo`
  ADD CONSTRAINT `fk_modelo_montadora1` FOREIGN KEY (`idmontadora`) REFERENCES `montadora` (`idmontadora`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para tabelas `triade`
--
ALTER TABLE `triade`
  ADD CONSTRAINT `fk_triade_veiculo1` FOREIGN KEY (`idcarro`) REFERENCES `veiculo` (`idcarro`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_versao_has_ano_ano1` FOREIGN KEY (`id_ano`) REFERENCES `ano` (`id_ano`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_versao_has_ano_modelo1` FOREIGN KEY (`idmodelo`) REFERENCES `modelo` (`idmodelo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_versao_has_ano_versao1` FOREIGN KEY (`id_versao`) REFERENCES `versao` (`id_versao`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
