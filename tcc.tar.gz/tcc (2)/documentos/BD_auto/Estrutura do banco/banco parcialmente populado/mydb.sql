-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Tempo de geração: 19/06/2018 às 13:26
-- Versão do servidor: 5.7.21-0ubuntu0.16.04.1
-- Versão do PHP: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `mydb`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `modelo`
--

CREATE TABLE `modelo` (
  `idmodelo` int(11) NOT NULL,
  `nome_modelo` varchar(45) DEFAULT NULL,
  `montadora_idmontadora` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `modelo`
--

INSERT INTO `modelo` (`idmodelo`, `nome_modelo`, `montadora_idmontadora`) VALUES
(1, 'Integra GS 1.8', 1),
(2, 'Legend 3.2/3.5', 1),
(3, 'NSX 3.0', 1),
(4, 'Cobalt Elite 1.8 AT', 23),
(5, 'Cobalt LT 1.4', 23),
(6, 'Cobalt LTZ 1.8 AT', 23),
(7, 'Cobalt Elite 1.8 AT', 23),
(8, 'Cobalt LTZ 1.8 AT', 23),
(9, 'Fiesta SE Plus 1.6 16V AT', 22),
(10, 'Fiesta SEL 1.6 16V AT', 22),
(11, 'Fiesta Titanium Plus 1.6 16V AT', 22),
(12, 'Fiesta SE 1.6 16V AT', 22),
(13, 'Fiesta Sport 1.6 16V', 22),
(14, 'Fiesta Titanium 1.6 16V AT', 22),
(15, 'Mustang 2.3 Turbo', 22),
(16, 'Mustang GT 5.0 V8', 22),
(17, 'Mustang Shelby GT350 5.2 V8', 22),
(18, 'Ranger limited 3.2 turbo 4x4 AT CD', 22),
(19, 'Ranger XLS 2.2 Turbo 4x4 CD', 22),
(20, 'Ranger XLT 3.2 Turbo 4x4 AT CD', 22),
(21, 'Galaxie Landau 5.0 V8', 22),
(22, 'Renegade Longitude 2.0 Turbo', 29),
(23, 'Renegade Sport 2.0 Turbo', 29),
(24, 'Renegade Trailwawk 2.0 Turbo', 29),
(25, 'Compass Longitude 2.0 Turbo', 29),
(26, 'Compass Trailhawk 2.0 Turbo', 29),
(27, 'Grand Cherokee limited 3.6 V6', 29),
(28, 'Cherokee Trailhawk 3.2 V6', 29),
(29, 'Fox Comfortline 1.6 I-Motion', 59),
(30, 'Fox Highline 1.6 16V I-Motion', 59),
(31, 'Fox Pepper 1.6 16V I-Motion', 59),
(32, 'Fox trendline 1.6', 59);

-- --------------------------------------------------------

--
-- Estrutura para tabela `modelo_ano`
--

CREATE TABLE `modelo_ano` (
  `idveiculo` int(11) NOT NULL,
  `ano` varchar(45) DEFAULT NULL,
  `potencia` varchar(45) DEFAULT NULL,
  `portas` varchar(45) DEFAULT NULL,
  `preco` varchar(45) DEFAULT NULL,
  `altura` varchar(45) DEFAULT NULL,
  `comprimento` varchar(45) DEFAULT NULL,
  `largura` varchar(45) DEFAULT NULL,
  `cambio` varchar(45) DEFAULT NULL,
  `velocidade` varchar(45) DEFAULT NULL,
  `tanque_combustivel` varchar(45) DEFAULT NULL,
  `tip_combustivel` varchar(45) DEFAULT NULL,
  `porta_malas` varchar(45) DEFAULT NULL,
  `tip_direcao` varchar(45) DEFAULT NULL,
  `consumo_urb` varchar(45) DEFAULT NULL,
  `consumo_rod` varchar(45) DEFAULT NULL,
  `marcha` varchar(45) DEFAULT NULL,
  `tip_tracao` varchar(45) DEFAULT NULL,
  `porte` varchar(45) DEFAULT NULL,
  `ocupantes` varchar(45) DEFAULT NULL,
  `tip_freio` varchar(45) DEFAULT NULL,
  `tip_veiculo` varchar(45) DEFAULT NULL,
  `modelo_idmodelo` int(11) NOT NULL,
  `like` int(11) DEFAULT NULL,
  `dislike` int(11) DEFAULT NULL,
  `usuario_idusuario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `modelo_ano`
--

INSERT INTO `modelo_ano` (`idveiculo`, `ano`, `potencia`, `portas`, `preco`, `altura`, `comprimento`, `largura`, `cambio`, `velocidade`, `tanque_combustivel`, `tip_combustivel`, `porta_malas`, `tip_direcao`, `consumo_urb`, `consumo_rod`, `marcha`, `tip_tracao`, `porte`, `ocupantes`, `tip_freio`, `tip_veiculo`, `modelo_idmodelo`, `like`, `dislike`, `usuario_idusuario`) VALUES
(1, '1991', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', '?', 1, NULL, NULL, NULL),
(2, '2017', '111 cv (A) 106 cv (g) a 5200 RPM', '4 portas', 'R$ 64189.00', '1504 mm', '4481 mm', '1735 mm', 'Automático', '170 km/h', '54 litros', 'Fléx', '563 litros', 'Elétrica', '7.6 km/l (A) 11.1 km/l (G)', '10 km/l (A) 14.4 km/l (G)', '6 marchas', 'Dianteira', 'Compacto', '5 passageiros', 'Disco ventilado', 'Sedã', 4, NULL, NULL, NULL),
(3, '2017', '106 cv (A) 98 cv (G) a 6000 RPM', '4 portas', 'R$ 46933,00', '1523 mm', '4481 mm', '1735 mm', 'Manual', '170 km/h', '54 litros', 'Fléx', '563 litros', 'Elétrica', '8.5 km/l (A) 12.5 km/l (G)', '10.4 km/l (A) 15.1 km/l (G)', '6 marchas', 'Dianteira', 'Compacto', '5 passageiros', 'Disco ventilado', 'Sedã', 5, NULL, NULL, NULL),
(4, '2017', '111 cv (A) 106 cv (G) a 5200 RPM', '4 portas', 'R$ 61015.00', '1508 mm', '4481 mm', '1735 mm', 'Automático', '170 km/h', '54 litros', 'Fléx', '563 litros', 'Elétrica', '7.6 km/l (A) 11.1 km/l (G)', '10 km/l (A) 14.4 km/l (G)', '6 marchas', 'Dianteira', 'Compacto', '5 passageiros', 'Disco ventilado', 'Sedã', 6, NULL, NULL, NULL),
(5, '2016', '108 cv (A) 106 cv (G) a 5200 RPM', '4 portas', 'R$ 58277.00', '1523 mm', '4481 mm', '1735 mm', 'Automático', '170 km/h', '54 litros', 'Fléx', '563 litros', 'Elétrica', '6.9 km/l (A) 8.9 km/l (G)', '9.5 km/l (A) 12.3 km/l (G)', '6 marchas', 'Dianteira', 'Compacto', '5 passageiros', 'Disco ventilado', 'Sedã', 7, NULL, NULL, NULL),
(6, '2016', '108 cv (A) 106 cv (G) a 5400 RPM', '4 portas', 'R$ 55233.00', '1523 mm', '4481 mm', '1735 mm', 'Automático', '170 km/h', '54 litros', 'Fléx', '563 litros', 'hidráulica', '6.9 km/l (A) 8.9 km/l (G)', '9.5 km/l (A) 12.3 km/l (G)', '6 marchas', 'Dianteira', 'Compacto', '5 passageiros', 'Disco ventilado', 'Sedã', 8, NULL, NULL, NULL),
(7, '2017', '128 cv (A) 125 cv (G) a 6500 RPM', '4 portas', 'R$ 55990.00', '1464 mm', '3969 mm', '1722 mm', 'Automatizado', '190 km/h', '51 litros', 'Fléx', '281 litros', 'Elétrica', '7.8 km/l (A) 11.2 km/l (G)', '10.3 km/l (A) 14.9 km/l (G)', '6 marchas', 'Dianteira', 'Compacto', '5 passageiros', 'Disco ventilado', 'Hatch', 9, NULL, NULL, NULL),
(8, '2017', '128 cv (A) 125 cv (G) a 6500 RPM', '4 portas', 'R$ 54922.00', '1464 mm', '3949 mm', '1722 mm', 'Automatizado', '190 km/h', '51 litros', 'Fléx', '281 litros', 'Elétrica', '7.8 km/l (A) 11.2 km/l (G)', '10.3 km/l (A) 14.9 km/l (G)', '6 marchas', 'Dianteira', 'Compacto', '5 passageiros', 'Disco ventilado', 'Hatch', 10, NULL, NULL, NULL),
(9, '2017', '128 cv (A) 126 cv (G) a 6500 RPM', '4 portas', 'R$ 60504.00', '1464 mm', '3969 mm', '1722 mm', 'Automatizado', '190 km/h', '51 litros', 'Fléx', '281 litros', 'Elétrica', '7.8 km/l (A) 11.2 km/l (G)', '10.3 km/l (A) 14.9 km/l (G)', '6 marchas', 'Dianteira', 'Compacto', '5 passageiros', 'Disco ventilado', 'Hatch', 11, NULL, NULL, NULL),
(10, '2016', '128 cv (A) 126 cv (G) a 6500 RPM', '4 portas', 'R$ 46032.00', '1464 mm', '3969 mm', '1722 mm', 'Automatizado', '190 km/h', '51 litros', 'Fléx', '281 litros', 'Elétrica', '7.7 km/l (A) 11 km/l (G)', '10 km/l (A) 14.3 km/l (G)', '6 marchas', 'Dianteira', 'Compacto', '5 passageiros', 'Disco ventilado', 'Hatch', 12, NULL, NULL, NULL),
(11, '2016', '128 cv (A) 126 cv (G) a 6500 RPM', '4 portas', 'R$ 49030.00', '1464 mm', '3969 mm', '1722 mm', 'Manual', '190 km/h', '51 litros', 'Fléx', '281 litros', 'Elétrica', '8 km/l (A) 12 km/l (G)', '10 km/l (A) 14.3 km/l (G)', '6 marchas', 'Dianteira', 'Compacto', '5 passageiros', 'Disco ventilado', 'Hatch', 13, NULL, NULL, NULL),
(12, '2016', '128 cv (A) 126 cv (G) a 6500 RPM', '4 portas', 'R$ 57917.00', '1464 mm', '3969 mm', '1722 mm', 'Automatizado', '190 km/h', '51 litros', 'Fléx', '281 litros', 'Elétrica', '7.7 km/l (A) 11 km/l (G)', '10 km/l (A) 14.3 km/l (G)', '6 marchas', 'Dianteira', 'Compacto', '5 passageiros', 'Disco ventilado', 'Hatch', 14, NULL, NULL, NULL),
(13, '2017', '314 cv a 5500 RPM', '2 portas', 'R$ 215000.00', '1382 mm', '4783 mm', '1915 mm', 'Automático', '259 km/h', '58 litros', 'Gasolina', '382 litros', 'Elétrica', '5.4 km/l', '10.4 km/l', '6 marchas', 'Traseira', 'Grande', '4 passageiros', 'Disco ventilado', 'Cupê', 15, NULL, NULL, NULL),
(14, '2017', '441 cv a 6500 rpm', '2 portas', 'R$ 270000.00', '1382 mm', '4783 mm', '1915 mm', 'Manual', '282 km/h', '60 litros', 'Gasolina', '382 litros', 'Elétrica', '3.3 km/l', '6.6 km/l', '6 marchas', 'Traseira', 'Grande', '4 passageiros', 'Disco ventilado', 'Cupê', 16, NULL, NULL, NULL),
(15, '2017', '533 cv a 7500 rpm', '2 portas', 'R$ 420000.00', '1382 mm', '4783 mm', '1915 mm', 'manual', '282km/h', '60 litros', 'Gasolina', '382 litros', 'Elétrica', '3.1 km/l', '6.4 km/l', '6 marchas', 'Traseira', 'Grande', '4 passageiros', 'Disco ventilado', 'Cupê', 17, NULL, NULL, NULL),
(16, '2017', '200 cv a 3000 rpm', '4 portas', 'R$ 160396.00', '1848 mm', '5354 mm', '1860 mm', 'Automático', '180 km/h', '80 litros', 'Diesel', '1180 litros', 'Elétrica', '8.5 km/l', '10.1 km/l', '6 marchas', 'Integral', 'Médio', '5 passageiros', 'Disco ventilado', 'Picape', 18, NULL, NULL, NULL),
(17, '2017', '160 cv a 3200 rpm', '4 portas', 'R$ 112068.00', '1815 mm', '5354 mm', '1860 mm', 'Manual', '164 km/h', '80 litros', 'Diesel', '1180 litros', 'Elétrica', '8.5 km/l', '10.5 km/l', '6 marchas', 'Integral', 'Médio', '5 passageiros', 'Disco ventilado', 'Picape', 19, NULL, NULL, NULL),
(18, '2017', '200 cv a 3000 rpm', '4 portas', 'R$ 141433.00', '1815 mm', '5354 mm', '1860 mm', 'Automático', '180 km/h', '80 litros', 'Diesel', '1180 litros', 'Elétrica', '8.3 km/l', '9.5 km/l', '6 marchas', 'Integral', 'Médio', '5 passageiros', 'Disco ventilado', 'Picape', 20, NULL, NULL, NULL),
(19, '1980', '199 cv a 4600 rpm', '6 portas', 'R$ 22000.00', '1412 mm', '5413 mm', '1999 mm', 'Automatico', '161 km/h', '107 litros', 'Gasolina', '400 litros', 'hidráulica', '3.9 km/l', '7 km/l', '3 marchas', 'Traseira', 'Grande', '6 passageiros', 'Disco Sólido', 'Sedã', 21, NULL, NULL, NULL),
(20, '2017', '170 cv a 3750 rpm', '4 portas', 'R$ 106650.00', '1716 mm', '4242 mm', '1798 mm', 'Automático', '190 km/h', '60 litros', 'Diesel', '260 litros', 'Elétrica', '9.4 km/l', '11.5 km/l', '9 marchas', 'Integral', 'Compacto', '5 passageiros', 'Disco ventilado', 'SUV', 22, NULL, NULL, NULL),
(21, '2017', '170 cv a 3750 rpm', '4 portas', 'R$ 99327.00', '1686 mm', '4232 mm', '1798 mm', 'Automático', '190 km/h', '60 litros', 'Diesel', '260 litros', 'Elétrica', '9.4 km/l', '11.5 km/l', '9 marchas', 'Integral', 'Compacto', '5 passageiros', 'Disco ventilado', 'SUV', 23, NULL, NULL, NULL),
(22, '2017', '170 cv a 3750 rpm', '4 portas', 'R$ 118813.00', '1725 mm', '4242 mm', '1798 mm', 'Automático', '190 km/h', '60 litros', 'Diesel', '260 litros', 'Elétrica', '9.4 km/l', '11.5 km/l', '9 marchas', 'Integral', 'Compacto', '5 passageiros', 'Disco ventilado', 'SUV', 24, NULL, NULL, NULL),
(23, '2017', '170 cv a 3750 rpm', '4 portas', 'R$ 121676.00', '1645 mm', '4416 mm', '1819 mm', 'Automático', '194 km/h', '60 litros', 'Diesel', '410 litros', 'Elétrica', '9.8 km/l', '11.4 km/l', '9 marchas', 'Integral', 'Médio', '5 passageiros', 'Disco ventilado', 'SUV', 25, NULL, NULL, NULL),
(24, '2017', '170 cv a 3750 rpm', '4 portas', 'R$ 141997.00', '1654 mm', '4416 mm', '1819 mm', 'Automático', '194 km/h', '60 litros', 'Diesel', '388 litros', 'Elétrica', '9.8 km/l', '11.4 km/l', '9 marchas', 'Integral', 'Médio', '5 passageiros', 'Disco ventilado', 'SUV', 26, NULL, NULL, NULL),
(25, '2015', '286 cv a 6350 rpm', '4 portas', 'R$ 250031.00', '1802 mm', '4828 mm', '1943 mm', 'Automático', '206 km/h', '93 litros', '93', '457 litros', 'Eletro-hidráulica', '5.9 km/l', '7.7 km/l', '8 marchas', 'Integral', 'Grande', '5 passageiros', 'Disco ventilado', 'SUV', 27, NULL, NULL, NULL),
(26, '2015', '271 cv a 6500 rpm', '4 portas', 'R$ 173558.00', '1723 mm', '4624 mm', '1904 mm', 'Automático', '206 km/h', '60 litros', 'Gasolina', '412 litros', 'Elétrica', '7.2 km/l', '9.4 km/l', '9 marchas', 'Integral', 'Médio', '5 passageiros', 'Disco ventilado', 'SUV', 28, NULL, NULL, NULL),
(27, '2017', '104 cv (A) 101 c (G) a 5250 rpm', '4 portas', 'R$ 48295.00', '1552 mm', '3848 mm', '1660 mm', 'Automatizado', '183 km/h', '50 litros', 'Fléx', '270 litros', 'Elétrica', '7.3 km/l (A) 10.3 km/l (G)', '8.2 km/l (A) 11.7 km/l (G)', '5 marchas', 'Dianteira', 'Compacto', '5 passageiros', 'Disco ventilado', 'Hatch', 29, NULL, NULL, NULL),
(28, '2017', '120 cv (A) 110 cv (G) a 5750 rpm', '4 portas', 'R$ 51894.00', '1552 mm', '3868 mm', '1660 mm', 'Automatizado', '189 km/h', '50 litros', 'Fléx', '270 litros', 'Elétrica', '7.4 km/l (A) 10.4 km/l (G)', '8.1 km/l (A) 11.6 km/l (G)', '5 marchas', 'Dianteira', 'Compacto', '5 passageiros', 'Disco ventilado', 'Hatch', 30, NULL, NULL, NULL),
(29, '2017', '120 cv (A) 110 cv (G) a 5250 rpm', '4 portas', 'R$ 51921.00', '1552 mm', '3868 mm', '1660 mm', 'Automatizado', '189 km/h', '50 litros', 'Fléx', '270 litros', 'Elétrica', '7.4 km/l (A) 10.4 km/l (G)', '8.1 km/l (A) 11.6 km/l (G)', '5 marchas', 'Dianteira', 'Compacto', '5 passageiros', 'Disco ventilado', 'hatch', 31, NULL, NULL, NULL),
(30, '2017', '104 cv (A) 101 cv (G) a 5250 rpm', '4 portas', 'R$ 43705.00', '1552 mm', '3868 mm', '1660 mm', 'Manual', '183 km/h', '50 litros', 'Fléx', '270 litros', 'Elétrica', '7.4 km/h (A) 10.4 km/l (G)', '8.2 km/l (A) 11.8 km/l (G)', '5 marchas', 'Dianteira', 'Compacto', '5 passageiros', 'Disco ventilado', 'Hatch', 32, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `montadora`
--

CREATE TABLE `montadora` (
  `idmontadora` int(11) NOT NULL,
  `montadora` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `montadora`
--

INSERT INTO `montadora` (`idmontadora`, `montadora`) VALUES
(1, 'Acura'),
(2, 'Agrale'),
(3, 'Alfa Romeo'),
(4, 'AM Gen'),
(5, 'Asia Motors'),
(6, 'Audi'),
(7, 'BMW'),
(8, 'BRM'),
(10, 'Cadillac'),
(11, 'CBT Jipe'),
(12, 'Chrysler'),
(13, 'Citroën'),
(14, 'Cross Lander'),
(15, 'Daewoo'),
(16, 'Daihatsu'),
(17, 'Dodge'),
(18, 'Engesa'),
(19, 'Envemo'),
(20, 'Ferrari'),
(21, 'Fiat'),
(22, 'Ford'),
(23, 'GM - Chevrolet'),
(24, 'Gurgel'),
(25, 'Honda'),
(26, 'Hyundai'),
(27, 'Isuzu'),
(28, 'Jaguar'),
(29, 'Jeep'),
(30, 'JPX'),
(31, 'Kia Motors'),
(32, 'Lada'),
(33, 'Land Rover'),
(34, 'Lexus'),
(35, 'Lotus'),
(36, 'Maserati'),
(37, 'Matra'),
(38, 'Mazda'),
(39, 'Mercedes-Benz'),
(40, 'Mercury'),
(41, 'Mitsubishi'),
(42, 'Miura'),
(43, 'Nissan'),
(44, 'Peugeot'),
(45, 'Plymouth'),
(46, 'Pontiac'),
(47, 'Porsche'),
(48, 'Renault'),
(49, 'Rover'),
(50, 'Saab'),
(51, 'Saturn'),
(52, 'Seat'),
(54, 'Subaru'),
(55, 'Suzuki'),
(56, 'Toyota'),
(57, 'Troller'),
(58, 'Volvo'),
(59, 'VW - VolksWagen'),
(120, 'Walk'),
(123, 'Bugre'),
(125, 'SSANGYONG'),
(127, 'LOBINI'),
(136, 'CHANA'),
(140, 'Mahindra'),
(147, 'EFFA'),
(149, 'Fibravan'),
(152, 'HAFEI'),
(153, 'GREAT WALL'),
(154, 'JINBEI'),
(156, 'MINI'),
(157, 'smart'),
(161, 'CHERY'),
(163, 'Wake'),
(165, 'TAC'),
(167, 'MG'),
(168, 'LIFAN'),
(170, 'Fyber'),
(171, 'LAMBORGHINI'),
(177, 'JAC'),
(182, 'CHANGAN'),
(183, 'SHINERAY'),
(185, 'RAM'),
(186, 'RELY'),
(189, 'ASTON MARTIN'),
(190, 'FOTON'),
(195, 'Rolls-Royce'),
(199, 'GEELY'),
(207, 'Baby');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

CREATE TABLE `usuario` (
  `idusuario` int(11) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `senha` varchar(45) DEFAULT NULL,
  `tip_usuario` varchar(45) DEFAULT NULL,
  `nome` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario_has_modelo`
--

CREATE TABLE `usuario_has_modelo` (
  `usuario_idusuario` int(11) NOT NULL,
  `modelo_idmodelo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `modelo`
--
ALTER TABLE `modelo`
  ADD PRIMARY KEY (`idmodelo`),
  ADD KEY `fk_modelo_montadora1_idx` (`montadora_idmontadora`);

--
-- Índices de tabela `modelo_ano`
--
ALTER TABLE `modelo_ano`
  ADD PRIMARY KEY (`idveiculo`),
  ADD KEY `fk_veiculo_modelo1_idx` (`modelo_idmodelo`),
  ADD KEY `fk_veiculo_usuario1_idx` (`usuario_idusuario`);

--
-- Índices de tabela `montadora`
--
ALTER TABLE `montadora`
  ADD PRIMARY KEY (`idmontadora`);

--
-- Índices de tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`idusuario`);

--
-- Índices de tabela `usuario_has_modelo`
--
ALTER TABLE `usuario_has_modelo`
  ADD PRIMARY KEY (`usuario_idusuario`,`modelo_idmodelo`),
  ADD KEY `fk_usuario_has_modelo_modelo1_idx` (`modelo_idmodelo`),
  ADD KEY `fk_usuario_has_modelo_usuario1_idx` (`usuario_idusuario`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `modelo`
--
ALTER TABLE `modelo`
  MODIFY `idmodelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT de tabela `modelo_ano`
--
ALTER TABLE `modelo_ano`
  MODIFY `idveiculo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `idusuario` int(11) NOT NULL AUTO_INCREMENT;
--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `modelo`
--
ALTER TABLE `modelo`
  ADD CONSTRAINT `fk_modelo_montadora1` FOREIGN KEY (`montadora_idmontadora`) REFERENCES `montadora` (`idmontadora`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para tabelas `modelo_ano`
--
ALTER TABLE `modelo_ano`
  ADD CONSTRAINT `fk_veiculo_modelo1` FOREIGN KEY (`modelo_idmodelo`) REFERENCES `modelo` (`idmodelo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_veiculo_usuario1` FOREIGN KEY (`usuario_idusuario`) REFERENCES `usuario` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para tabelas `usuario_has_modelo`
--
ALTER TABLE `usuario_has_modelo`
  ADD CONSTRAINT `fk_usuario_has_modelo_modelo1` FOREIGN KEY (`modelo_idmodelo`) REFERENCES `modelo` (`idmodelo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_usuario_has_modelo_usuario1` FOREIGN KEY (`usuario_idusuario`) REFERENCES `usuario` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
