<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 19/03/18
 * Time: 16:00
 */
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Página Inicial</title>
    <link rel="shortut icon" href="../../assets/images/Vs_black.png" type="image/x-icon">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../node_modules/semantic-ui/dist/semantic.min.css">
    <link rel="stylesheet" type="text/css" href="../../assets/css/menu.css">
	<script
  		src="https://code.jquery.com/jquery-3.1.1.min.js"
  		integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  		crossorigin="anonymous"></script>
	<script src="../../node_modules/semantic-ui/dist/semantic.min.js"></script>
    <script src="../../assets/java%20script/select.js"></script>
    <style type="text/css">
    	@media only screen and (max-width: 700px) {
    		.ui.fixed.menu {
    			display: none !important;
    		}
    	}
    </style>
</head>
<body>
<div class="ui massive attached stackable container top menu">
    <div class="item left floated">
        <h1>VERSUS X</h1>
    </div>            
                <a class="item bg" href="?action=index">Início</a>
            <?php
            if (!isset($_SESSION['logado'])){?>
                <a class="item bg" href="?actioni=login">Logar</a>
                <a class="item bg" href="?actioni=cadastrar">Cadastrar</a>
            <?php }
            ?><a class="item bg" href="?actioni=sobre">Sobre e Contatos</a>
            <?php
            if (isset($_SESSION['logado'])){?>
<!--                <a class="item" href="#">Perfil</a>-->

                <a class="item bg" href="?actioni=comment">Comentários</a>
                <a class="item bg" href="?action=sair">Sair</a>
            <?php
            if (isset($_SESSION['logado']) and isset($_SESSION['tipo'])){?>
                <a class="item bg" href="?action=listausuario">Admin</a>
            <?php } ?>
            <?php } ?>
    </div>
<br>
<br>
<br>

<?php
if (!isset($_SESSION['logado']) and isset($_GET['actioni']) and $_GET['actioni'] == 'login') {
    include_once "../views/form/login.php";
}elseif (!isset($_SESSION['logado']) and isset($_GET['actioni']) and $_GET['actioni'] == 'cadastrar'){
    include_once "../views/form/cadastro.php";
}elseif (isset($_GET['actioni']) and $_GET['actioni'] == 'sobre') {
    include_once "../views/tab/about us.php";
}elseif (isset($_GET['actioni']) and $_GET['actioni'] == 'comment') {
    include_once "../views/tab/comment.php";
}elseif (!isset($_GET['actioni'])) {
?>

    <div class="ui middle aligned center aligned grid">
            <div class="content">
                <h2 style="color: white;">COMPARE OS CARROS AQUI</h2>
            </div>
<br>
<br>

<div class="ui center aligned segment">
    <br>
    <br>
    <form class="ui form large" method="post" action="controladorComp.php">
        <div class="ui grid">
            <?php
                $url = 'http://fipeapi.appspot.com/api/1/carros/marcas.json'; // marcas

            //http://fipeapi.appspot.com/api/1/carros/veiculos/21.json // veiculos da marca 21

                $data = file_get_contents($url); // put the contents of the file into a variable
                $marcas = json_decode($data); // decode the JSON feed
            ?>
            <div class="four wide column">
                <?php

                    echo '<select name="marca" id="marca" class="select-marca">';
                    echo '<option selected>Selecione...</option>';
                    foreach ($marcas as $marca) {
                        echo '<option value="'.$marca->id.'">'.$marca->name.'</option>';
                    }

                    echo '</select>';
                ?>

                <select name="modelo" id="modelo" class="select-modelo">
                    <option>Selecione...</option>
                </select>

                <select name="ano" id="ano" class="select-ano">
                    <option>Selecione...</option>
                </select>

                <div class="carregando" style="color: white;"><h3>Carregando...</h3></div>
            </div>


            <div class="four wide column">
                <?php

                    echo '<select name="marca1" id="marca1" class="select-marca">';
                    echo '<option selected>Selecione...</option>';
                    foreach ($marcas as $marca) {
                        echo '<option value="'.$marca->id.'">'.$marca->name.'</option>';
                    }

                    echo '</select>';
                ?>
                <select name="modelo1" id="modelo1" class="select-modelo">
                    <option>Selecione...</option>
                </select>

                <select name="ano1" id="ano1" class="select-ano">
                    <option>Selecione...</option>
                </select>

                <div class="carregando" style="color: white;"><h3>Carregando...</h3></div>
            </div>


            <div class="four wide column">
                <?php

                    echo '<select name="marca2" id="marca2" class="select-marca">';
                    echo '<option selected>Selecione...</option>';
                    foreach ($marcas as $marca) {
                        echo '<option value="'.$marca->id.'">'.$marca->name.'</option>';
                    }

                    echo '</select>';
                ?>
                <select name="modelo2" id="modelo2" class="select-modelo">
                    <option>Selecione...</option>
                </select>

                <select name="ano2" id="ano2" class="select-ano">
                    <option>Selecione...</option>
                </select>

                <div class="carregando" style="color: white;"><h3>Carregando...</h3></div>
            </div>



            <div class="four wide column">
                <?php

                    echo '<select name="marca3" id="marca3" class="select-marca">';
                    echo '<option selected>Selecione...</option>';
                    foreach ($marcas as $marca) {
                        echo '<option value="'.$marca->id.'">'.$marca->name.'</option>';
                    }

                    echo '</select>';
                ?>
                <select name="modelo3" id="modelo3" class="select-modelo">
                    <option>Selecione...</option>
                </select>

                <select name="ano3" id="ano3" class="select-ano">
                    <option>Selecione...</option>
                </select>

                <div class="carregando" style="color: white;"><h3>Carregando...</h3></div>
            </div>
            <div class="ui center aligned">
                <div class="ui horizontal divider">
                    Terminou, basta clicar em Enviar
                </div>
                <button class="ui green labeled icon button submit">
                    Enviar
                    <i class="angle double right icon"></i>
                </button>
            </div>
    <br>
    </form>
    </div>
    </div>

<?php } ?>
<div<?php include_once "../views/template/rodape.php";?><div></div>
</body>
</html>