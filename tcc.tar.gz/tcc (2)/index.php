<?php
    header("location: app/controllers/controladorAcao.php");
?>